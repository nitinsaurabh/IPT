/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.hotel;

import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;
import javax.jws.Oneway;

/**
 *
 * @author pritishrawal
 */
@WebService(serviceName = "hotelserv")
@Stateless()
public class hotelserv {

int seat=100,month,year,day,no;
String city,nam;
int std=100,suite,del,bookid=0;
String bookdate;

    /**
     * Web service operation
     */
    @WebMethod(operationName = "bookroom")
    public String bookroom(@WebParam(name = "name") String name, @WebParam(name = "noguest") int noguest, @WebParam(name = "city") String city) {
        //TODO write your implementation code here:
        seat-=noguest;
        no=noguest;
        nam=name;
        city=city;
         Calendar cal=new GregorianCalendar();
         month =cal.get(Calendar.MONTH);
        year=cal.get(Calendar.YEAR);
       day=cal.get(Calendar.DAY_OF_MONTH);
       bookdate=day+"/"+(month+1)+"/"+year;
       String Message="booking id is :"+bookid+" name is :"+nam+" seats is :"+noguest+" city is :"+city+" date is:"+bookdate+" cost is :"+std*no;
        
        return Message;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "genrecep")
    @Oneway
    public void genrecep() {
        bookid++;
        String Message="booking id is :"+bookid+",    name is :"+nam+",   seats is :"+no+",   city is :"+city+",    date is:"+bookdate+",    cost is :"+std*no;
        
        
       
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getprice")
    public int getprice(@WebParam(name = "no") int no, @WebParam(name = "city") String city, @WebParam(name = "std") int std, @WebParam(name = "del") int del, @WebParam(name = "suite") int suite) {
        //TODO write your implementation code here:
        no=no;
        city=city;
        std=std;
        
        return std;
    }
}
