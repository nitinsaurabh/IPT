/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.airline;
import javax.swing.JOptionPane; 

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;
import javax.jws.Oneway;
import java.util.Calendar;
import java.util.GregorianCalendar;
/**
 *
 * @author pritishrawal
 */
@WebService(serviceName = "airline")
@Stateless()
public class airline {

int left_s=100,month,year,day,seats;
String org,desti,nam;
int eco,busi,bookid=0;
String bookdate,Message;
    /**
     * Web service operation
     */
    @WebMethod(operationName = "getAvail")
    public int getAvail(@WebParam(name = "seats") int seats, @WebParam(name = "origin") String origin, @WebParam(name = "dest") String dest, @WebParam(name = "eco_price") int eco_price, @WebParam(name = "busi_price") int busi_price) {
        //TODO write your implementation code here:
        this.seats=seats;
        this.org=origin;
        this.desti=dest;
        eco=eco_price;
        busi=busi_price;
        return left_s;
    }

    /**
     * Web service operation
     * @param name
     * @param seats
     * @param origin
     * @param destination
     * @param date
     * @return 
     */
    @WebMethod(operationName = "bookFlight")
    public String bookFlight(@WebParam(name = "name") String name, @WebParam(name = "seats") int seats, @WebParam(name = "origin") String origin, @WebParam(name = "destination") String destination, @WebParam(name = "date")GregorianCalendar.Builder date) {
        //TODO write your implementation code here:
        left_s-=seats;
        nam=name;
         Calendar cal=new GregorianCalendar();
         month =cal.get(Calendar.MONTH);
        year=cal.get(Calendar.YEAR);
       day=cal.get(Calendar.DAY_OF_MONTH);
       bookdate=day+"/"+(month+1)+"/"+year;
       Message="booking id is :"+bookid+" name is :"+nam+" seats is :"+seats+" origin is :"+org+" destination is :"+desti+" date is:"+bookdate+" cost is :"+eco*seats;
        
        return Message;
       // return "booked";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "generate_receipt")
    @Oneway
    public void generate_receipt() {
        bookid++;
        String Message="booking id is :"+bookid+" name is :"+nam+" seats is :"+seats+" origin is :"+org+" destination is :"+desti+" date is:"+bookdate+" cost is :"+eco*seats;
        
        JOptionPane.showMessageDialog(null, Message, "PDF", 1);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "recep")
    public String recep() {
        bookid++;
       // String Message="booking id is :"+bookid+",    name is :"+nam+",   seats is :"+seats+",   origin is :"+org+",   destination is :"+desti+",    date is:"+bookdate+",    cost is :"+eco*seats;
        
   
        return Message;
    }
    
}
